
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// ext irq-b�l nem j� az LCD soros kommunik�ci�!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


#include <atmel_start.h>
#include <global.h>

#include <sounddata.h>

static struct timer_task TIMER_0_task1, TIMER_0_task2;

static bool adc_read;
static bool pb_received;
static uint16_t adc_value;
static uint32_t kb_value;

static uint16_t minvalue;
static uint32_t maxvalue;

static uint16_t pulse_counter;
static uint16_t TR_counter;

char buffer[64];

extern struct report event_report;
extern struct session session_data;
extern struct menu menu_structure;
extern struct session_temp_values session_temp;

extern bool ACK_received;
extern bool NAK_received;

const unsigned char switch_to_default_form[] =			{WRITE_OBJ,FORM,DEFAULT_FORM,0,0,WRITE_OBJ^FORM^DEFAULT_FORM};
const unsigned char switch_to_session_running_form[] =	{WRITE_OBJ,FORM,SESSION_RUNNING_FORM,0,0,WRITE_OBJ^FORM^SESSION_RUNNING_FORM};
const unsigned char switch_to_manual_trigger_form[] =	{WRITE_OBJ,FORM,MANUAL_TRIGGER_FORM,0,0,WRITE_OBJ^FORM^MANUAL_TRIGGER_FORM};
const unsigned char switch_to_simulation_running_form[] = {WRITE_OBJ,FORM,SIMULATION_RUNNING_FORM,0,0,WRITE_OBJ^FORM^SIMULATION_RUNNING_FORM};
const unsigned char switch_to_settings_1_form[] =		{WRITE_OBJ,FORM,SETTINGS_1_FORM,0,0,WRITE_OBJ^FORM^SETTINGS_1_FORM};
const unsigned char switch_to_settings_2_form[] =		{WRITE_OBJ,FORM,SETTINGS_2_FORM,0,0,WRITE_OBJ^FORM^SETTINGS_2_FORM};
const unsigned char switch_to_keyboard_form[] =			{WRITE_OBJ,FORM,KEYBOARD_FORM,0,0,WRITE_OBJ^FORM^KEYBOARD_FORM};
const unsigned char switch_to_menu_form[] =				{WRITE_OBJ,FORM,MENU_FORM,0,0,WRITE_OBJ^FORM^MENU_FORM};
const unsigned char switch_to_settings_3_form[] =		{WRITE_OBJ,FORM,SETTINGS_3_FORM,0,0,WRITE_OBJ^FORM^SETTINGS_3_FORM};
const unsigned char switch_to_about_form[] =			{WRITE_OBJ,FORM,ABOUT_FORM,0,0,WRITE_OBJ^FORM^ABOUT_FORM};


const unsigned char set_trigger_sound_off[] = {WRITE_OBJ,STRINGS,2,0,OFF,WRITE_OBJ^STRINGS^2^OFF};
const unsigned char set_trigger_sound_on[] = {WRITE_OBJ,STRINGS,2,0,ON,WRITE_OBJ^STRINGS^2^ON};
	
const unsigned char set_trigger_sound_switch_off[] = {WRITE_OBJ,FOURDBUTTON,0,0,OFF,WRITE_OBJ^FOURDBUTTON^0^OFF};
const unsigned char set_trigger_sound_switch_on[] = {WRITE_OBJ,FOURDBUTTON,0,0,ON,WRITE_OBJ^FOURDBUTTON^0^ON};

const unsigned char set_response_sound_off[] = {WRITE_OBJ,STRINGS,3,0,OFF,WRITE_OBJ^STRINGS^3^OFF};
const unsigned char set_response_sound_on[] = {WRITE_OBJ,STRINGS,3,0,ON,WRITE_OBJ^STRINGS^3^ON};
	
const unsigned char set_response_sound_switch_off[] = {WRITE_OBJ,FOURDBUTTON,1,0,OFF,WRITE_OBJ^FOURDBUTTON^1^OFF};
const unsigned char set_response_sound_switch_on[] = {WRITE_OBJ,FOURDBUTTON,1,0,ON,WRITE_OBJ^FOURDBUTTON^1^ON};
	
const unsigned char set_no_of_slices_txt[] =	{WRITE_OBJ,STRINGS,10,0,0,WRITE_OBJ^STRINGS^10^0};
const unsigned char set_no_of_volumes_txt[] =	{WRITE_OBJ,STRINGS,10,0,1,WRITE_OBJ^STRINGS^10^1};
const unsigned char set_trigg_slice_txt[] =		{WRITE_OBJ,STRINGS,10,0,2,WRITE_OBJ^STRINGS^10^2};
const unsigned char set_trigg_volume_txt[] =	{WRITE_OBJ,STRINGS,10,0,3,WRITE_OBJ^STRINGS^10^3};
const unsigned char set_pulse_length_txt[] =	{WRITE_OBJ,STRINGS,10,0,4,WRITE_OBJ^STRINGS^10^4};
const unsigned char set_tr_time_txt[] =			{WRITE_OBJ,STRINGS,10,0,5,WRITE_OBJ^STRINGS^10^5};


const unsigned char click[] =		{WRITE_OBJ,SOUND,PLAY,0,0,WRITE_OBJ^SOUND^PLAY^0};
const unsigned char trig_rcvd[] =	{WRITE_OBJ,SOUND,PLAY,0,1,WRITE_OBJ^SOUND^PLAY^1};
const unsigned char ses_start[] =	{WRITE_OBJ,SOUND,PLAY,0,2,WRITE_OBJ^SOUND^PLAY^2};
const unsigned char ses_stop[] =	{WRITE_OBJ,SOUND,PLAY,0,3,WRITE_OBJ^SOUND^PLAY^3};

const uint32_t ad = 0x3f000;

const uint8_t click_delay = 50;
static uint16_t timeout_counter = 0;
static uint8_t prescaler = PRESCALER_VALUE;

static uint8_t dc_out = 0;


void write_flash(){
	uint8_t delay = 10;
	
	int i;
	i = session_data.no_of_slices;
	char * ic = (char *) &i;  //https://stackoverflow.com/questions/3609972/converting-int-double-to-char-array-in-c-or-objective-c
	printf("flash write no of slices, %u\r\n", i);
	flash_write(&FLASH_0, ad, ic, 2);
	printf("flash written no of slices, %u, %u\r\n", ic[0], ic[1]);
	delay_ms(delay);
		
	i = session_data.no_of_volumes;
	ic = (char *) &i;
	printf("flash write no of volumes, %u\r\n", i);
	flash_write(&FLASH_0, ad + 2, ic, 2);
	printf("flash written no of volumes, %u, %u\r\n", ic[0], ic[1]);
	delay_ms(delay);
	
	i = session_data.trig_on_slice;
	ic = (char *) &i;
	printf("flash write trigg on slice, %u\r\n", i);
	flash_write(&FLASH_0, ad + 4, ic, 2);
	printf("flash written trigg on slice, %u, %u\r\n", ic[0], ic[1]);
	delay_ms(delay);
	
	i = session_data.trig_on_volume;
	ic = (char *) &i;
	printf("flash write trigg on volume, %u\r\n", i);
	flash_write(&FLASH_0, ad + 6, ic, 2);
	printf("flash written trigg on volume, %u, %u\r\n", ic[0], ic[1]);
	delay_ms(delay);
	
	i = session_data.pulse_length;
	ic = (char *) &i;
	printf("flash write pulse length, %u\r\n", i);
	flash_write(&FLASH_0, ad + 8, ic, 2);
	printf("flash written pulse lenght, %u, %u\r\n", ic[0], ic[1]);
	delay_ms(delay);

	i = session_data.TR_time;
	ic = (char *) &i;
	printf("flash write TR time, %u\r\n", i);
	flash_write(&FLASH_0, ad + 0x0a, ic, 2);
	printf("flash written TR time, %u, %u\r\n", ic[0], ic[1]);
	delay_ms(delay);	
	
	i = session_data.trigger_sound * 256 + session_data.response_sound;
	ic = (char *) &i;
	printf("flash write trigger / response sound, %u\r\n", i);
	flash_write(&FLASH_0, ad + 0x0c, ic, 2);
	printf("flash written trigger / response sound, %u, %u\r\n", ic[1], ic[0]);
	delay_ms(delay);
	
	i = session_data.sound_volume;
	ic = (char *) &i;
	printf("flash write sound volume, %u\r\n", i);
	flash_write(&FLASH_0, ad + 0x0e, ic, 2);
	printf("flash written sound volume, %u, %u\r\n", ic[0], ic[1]);
	delay_ms(delay);
}

void read_flash(){
		
	static uint8_t a[2];
	printf("read session data from flash\r\n");
	
	flash_read(&FLASH_0, ad, a, 2);	
	session_data.no_of_slices = a[0] + a[1] * 256;	
	printf("no_of_slices read from flash: %u\r\n", session_data.no_of_slices);
	
	if ((session_data.no_of_slices < 1) || (session_data.no_of_slices > 999)) {
		session_data.no_of_slices = 15;
	}	
	
	flash_read(&FLASH_0, ad + 2, a, 2);
	session_data.no_of_volumes = a[0] + a[1] * 256;
	printf("no_of_volumes read from flash: %u\r\n", session_data.no_of_volumes);
	
	if ((session_data.no_of_volumes < 1) || (session_data.no_of_volumes > 9999)) {
		session_data.no_of_volumes = 100;
	}
	
	flash_read(&FLASH_0, ad + 4, a, 2);
	session_data.trig_on_slice = a[0] + a[1] * 256;
	printf("trig_on_slice read from flash: %u\r\n", session_data.trig_on_slice);
	
	if ((session_data.trig_on_slice < 0) || (session_data.trig_on_slice > 999)) {
		session_data.trig_on_slice = 0;
	}
	
		
	flash_read(&FLASH_0, ad + 6, a, 2);
	session_data.trig_on_volume = a[0] + a[1] * 256;
	printf("trig_on_volume read from flash: %u\r\n", session_data.trig_on_volume);
	
	if ((session_data.trig_on_volume < 0) || (session_data.trig_on_volume > 9999)) {
		session_data.trig_on_volume = 0;
	}
		
	flash_read(&FLASH_0, ad + 8, a, 2);
	session_data.pulse_length = a[0] + a[1] * 256;
	printf("pulse_length read from flash: %u\r\n", session_data.pulse_length);
	
	if ((session_data.pulse_length < 10) || (session_data.pulse_length > 999)) {
		session_data.pulse_length = 10;
	}
		
	flash_read(&FLASH_0, ad + 0x0a, a, 2);
	session_data.TR_time = a[0] + a[1] * 256;
	printf("TR_time read from flash: %u\r\n", session_data.TR_time);
	
	
	uint32_t minvalue_long = session_data.pulse_length * session_data.no_of_slices;
	if (minvalue_long > 9999){   // hibaellen�rz�s!!!!!!!!!!!!
		minvalue_long = 9999;
	}

	if ((session_data.TR_time < minvalue_long) || (session_data.TR_time > 9999)) {  
		session_data.TR_time = minvalue_long;
	}
	
	
	
	flash_read(&FLASH_0, ad + 0x0c, a, 2);
	if (a[1] > 0){
		session_data.trigger_sound = true;
	}
	else{
		session_data.trigger_sound = false;
	}	
	
	if (a[0] > 0){
		session_data.response_sound = true;
	}
	else{
		session_data.response_sound = false;
	}
	printf("trigger / response sound: %u, %u\r\n", session_data.trigger_sound, session_data.response_sound);
	
		
	
	flash_read(&FLASH_0, ad + 0x0e, a, 2);
	session_data.sound_volume = a[0];
	printf("sound volume read from flash: %u\r\n", session_data.sound_volume);
	
	if ((session_data.sound_volume < 0) || (session_data.sound_volume > 127)) {
		session_data.sound_volume = 64;
	}
}

void resync(){
	printf("no ACK received, resync");
}

bool io_write_clear_ack(const uint8_t *const buf, const uint16_t length)
{
	unsigned char i;
	if (ACK_received){
		ACK_received = false;
		
		for (i = 0; i < length; i++)
		{
			io_write(&USART_1.io, &buf[i], 1);
			while(usart_async_is_tx_empty(&USART_1)!=1);  // waiting the tx is over		
		}
		return;
	}
	else{
		printf("start timeout");
		timeout_counter = ACK_TIMEOUT;
		while (timeout_counter){
			printf("%u\r\n", timeout_counter);
			if (ACK_received){
				break;
			}
		}
		if (ACK_received){
			printf("received an ACK finally...\r\n");
			printf("resend command\r\n");
			io_write_clear_ack(buf, length);
		}
		else{
			resync();
		}
	}
}

unsigned char getCRC(unsigned char message[], unsigned char length)
{
	unsigned char i, crc = 0;
	
	for (i = 0; i < length; i++)
	{
		crc ^= message[i];
	}
	return crc;
}

static void print_no(uint16_t number, uint8_t str_no){
		
	int16_t length = snprintf(buffer, 15, "___%u", number);
	
	buffer[0] = WRITE_STR;
	buffer[1] = str_no;
	buffer[2] = length-3;
	buffer[length] = getCRC(buffer, length);
	buffer[length+1] = 0; // ????????????
    io_write_clear_ack(buffer, length+1);
	printf("number: %u\r\n", number);
}

static void print_slices(uint8_t str_no){
	uint8_t length = snprintf(buffer, 64, "___%u / %u    ", session_data.current_slice, session_data.no_of_slices);
	buffer[0] = WRITE_STR;
	buffer[1] = str_no;
	buffer[2] = length-3;
	buffer[length] = getCRC(buffer, length);
	buffer[length+1] = 0; // ????????????
	io_write_clear_ack(buffer,length+1);
	printf("current slice: %u\r\n", session_data.current_slice);
}

static void print_volumes(uint8_t str_no){
	uint8_t length = snprintf(buffer, 64, "___%u / %u    ", session_data.current_volume, session_data.no_of_volumes);
	buffer[0] = WRITE_STR;
	buffer[1] = str_no;
	buffer[2] = length-3;
	buffer[length] = getCRC(buffer, length);
	buffer[length+1] = 0; // ????????????
	io_write_clear_ack(buffer,length+1);
	printf("**********current volume: %u\r\n", session_data.current_volume);
}

static void convert_cb_ADC_0(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
	adc_async_read_channel(&ADC_0, channel, &adc_value, 2);
	adc_read=true;
}

/**
 * ADC init
 */
void ADC_init(void)
{
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, convert_cb_ADC_0);
	adc_async_enable_channel(&ADC_0, 0);
}

static void set_prev_curr_form(const uint8_t form){
	session_data.previous_form = session_data.current_form;
	session_data.current_form = form;
}

static void switch_to_form(const uint8_t form)
{		
	//delay_ms(100);
	switch (form){
				
		case DEFAULT_FORM:
			printf("sw to default \r\n");
			io_write_clear_ack(switch_to_default_form,6);
			set_prev_curr_form(form);			
		break;
		
		case SESSION_RUNNING_FORM:
			printf("sw to ses running\r\n");
			io_write_clear_ack(switch_to_session_running_form,6);
			set_prev_curr_form(form);
		break;	
		
		case MANUAL_TRIGGER_FORM:
			printf("sw to man trig\r\n");
			io_write_clear_ack(switch_to_manual_trigger_form,6);
			set_prev_curr_form(form);
		break;
		
		case SIMULATION_RUNNING_FORM:
			printf("sw to sim running\r\n");
			io_write_clear_ack(switch_to_simulation_running_form,6);
			set_prev_curr_form(form);
		break;
				
		case SETTINGS_1_FORM:
			printf("switch to settings 1\r\n");
			io_write_clear_ack(switch_to_settings_1_form,6);
			set_prev_curr_form(form);
						
			if (session_data.response_sound){
				io_write_clear_ack(set_response_sound_on,6);
				io_write_clear_ack(set_response_sound_switch_on,6);
			}
			else{
				io_write_clear_ack(set_response_sound_off,6);
				io_write_clear_ack(set_response_sound_switch_off,6);
			}
						
			if (session_data.trigger_sound){
				io_write_clear_ack(set_trigger_sound_on,6);
				io_write_clear_ack(set_trigger_sound_switch_on,6);
			}
			else{
				io_write_clear_ack(set_trigger_sound_off,6);
				io_write_clear_ack(set_trigger_sound_switch_off,6);
			}
						
 			print_no(session_temp.no_of_volumes, SET_VOLUMES_STR);
  		 	print_no(session_temp.no_of_slices, SET_SLICES_STR);
		break;
		
		case SETTINGS_2_FORM:
			printf("sw to settings 2\r\n");
			io_write_clear_ack(switch_to_settings_2_form,6);
			set_prev_curr_form(form);
						
			print_no(session_temp.trig_on_slice, SLICE_TRIGGERNO_STR);
 			print_no(session_temp.trig_on_volume, VOLUME_TRIGGERNO_STR);
 			print_no(session_temp.pulse_length, PULSE_LENGTH_STR);
 			print_no(session_temp.TR_time, TR_TIME_STR);
		break;
		
		case SETTINGS_3_FORM:
			printf("sw to settings 3\r\n");
			io_write_clear_ack(switch_to_settings_3_form,6);
			set_prev_curr_form(form);
		break;
				
		case KEYBOARD_FORM:
			printf("sw to keyboard\r\n");
			io_write_clear_ack(switch_to_keyboard_form,6);
			set_prev_curr_form(form);
		break;
		
		case MENU_FORM:
			printf("sw to menu\r\n");
			io_write_clear_ack(switch_to_menu_form,6);
			set_prev_curr_form(form);
		break;		
		
		case ABOUT_FORM:
			printf("sw to about\r\n");
			io_write_clear_ack(switch_to_about_form,6);
			set_prev_curr_form(form);
		break;
	}	
}

void start_simulation()
{
	uint8_t length;
	printf("start simulation\r\n");
	
	pulse_counter = 0;
	TR_counter = 0;
	
	session_data.trigger = false;
	session_data.current_volume = 1;
	session_data.current_slice = 0;
	session_data.previous_volume = session_data.no_of_volumes;
	session_data.previous_slice = 0;
	session_data.simulated_A=false;
	session_data.simulated_B=false;
	session_data.simulated_C=false;
	session_data.simulated_D=false;
	session_data.manual_trigger=false;
	session_data.session_running= false;

	switch_to_form(SIMULATION_RUNNING_FORM);
	print_slices(SIMULATION_CURRENT_SLICE_STR);
	print_volumes(SIMULATION_CURRENT_VOLUME_STR);
	
// 	delay_ms(100);
// 	printf("playing start sound\r\n");
// 	io_write_clear_ack(ses_start,6);
	session_data.simulation_mode=true;
	
}

void stop_simulation()
{
	switch_to_form(MENU_FORM);
	
// 	delay_ms(100);
// 	printf("playing stop sound\r\n");
// 	io_write_clear_ack(ses_stop,6);
	
	session_data.session_running = false;
	session_data.simulation_mode = false;
	session_data.manual_trigger=false;
	session_data.trigger = false;
	session_data.current_volume = 1;
	session_data.current_slice = 0;
}


void start_man_trig()
{
	uint8_t length;		
	printf("start man trig\r\n");
		
	session_data.trigger = false;
	session_data.current_volume = 1;
	session_data.current_slice = 0;
	session_data.previous_volume = session_data.no_of_volumes;
	session_data.previous_slice = 0;
	session_data.simulated_A=false;
	session_data.simulated_B=false;
	session_data.simulated_C=false;
	session_data.simulated_D=false;
	session_data.simulation_mode=false;
	session_data.session_running= false;	
		
	switch_to_form(MANUAL_TRIGGER_FORM);
	print_slices(MAN_TRIG_CURRENT_SLICE_STR);
	print_volumes(MAN_TRIG_CURRENT_VOLUME_STR);

				
// 	delay_ms(100);
// 	printf("playing start sound\r\n");
// 	io_write_clear_ack(ses_start,6);
	session_data.manual_trigger=true;
	
}

void stop_man_trig()
{
	switch_to_form(MENU_FORM);
	
// 	delay_ms(100);
// 	printf("playing stop sound\r\n");
// 	io_write_clear_ack(ses_stop,6);
	
	session_data.session_running = false;
	session_data.simulation_mode = false;
	session_data.manual_trigger=false;
	session_data.trigger = false;
	session_data.current_volume = 1;
	session_data.current_slice = 0;
}


void start_session()
{
	uint8_t length;
	if ((adc_value > 1550) && (adc_value < 2000)) {
			
		printf("start session\r\n");
		
		session_data.trigger = false;
		session_data.current_volume = 1;
		session_data.current_slice = 0;
		session_data.previous_volume = session_data.no_of_volumes;
		session_data.previous_slice = 0;
		session_data.simulated_A=false;
		session_data.simulated_B=false;
		session_data.simulated_C=false;
		session_data.simulated_D=false;
		session_data.simulation_mode=false;
	
		switch_to_form(SESSION_RUNNING_FORM);
	
		printf("powering up TX ch. 1\r\n");
		gpio_set_pin_level(T1, true);
	
		printf("powering up TX ch. 2\r\n");
		gpio_set_pin_level(T2, true);
	
		print_slices(CURRENT_SLICE_STR);
		print_volumes(CURRENT_VOLUME_STR);
	
// 		delay_ms(100);
// 		printf("playing start sound\r\n");
// 		io_write_clear_ack(ses_start,6);
		session_data.session_running = true;
	}
	else {
		printf("incorrect power supply voltage\r\n");		
		printf("psup voltage is %d\r\n", adc_value);
	}
}

void stop_session()
{
	switch_to_form(DEFAULT_FORM);
	
// 	delay_ms(100);
// 	printf("playing stop sound\r\n");
// 	io_write_clear_ack(ses_stop,6);
	
	session_data.session_running = false;
	session_data.simulation_mode = false;
	session_data.trigger = false;
	session_data.current_volume = 1;
	session_data.current_slice = 0;
	
	printf("powering down TX ch. 1\r\n");
	gpio_set_pin_level(T1, false);
	printf("powering down TX ch. 2\r\n");
	gpio_set_pin_level(T2, false);	
}

static void button(void)	// called by ext irq
{
	pb_received = true;
	delay_ms(200); //debounce
}

static void sync_trigger(void)	// called by ext irq
{	
	if ((session_data.session_running) && (!session_data.trigger)){
		delay_ms(10);	
		session_data.current_slice += 1;
		if (session_data.current_slice > session_data.no_of_slices){
			session_data.current_volume += 1;	
			session_data.current_slice = 1;					
			}
		
		uint16_t divider = session_data.trig_on_volume;
		if (divider == 0) {
			divider = 1;
		}
		if ((session_data.current_volume % divider) == 0){
			if ((session_data.trig_on_slice == 0) || (session_data.trig_on_slice == session_data.current_slice)){
				session_data.trigger = true;
				if (session_data.trigger_sound){
					//io_write_clear_ack(trig_rcvd,6);
				}
			}
		}
	}	
}

static void TIMER_task1_cb(const struct timer_task *const timer_task)
   {	
		dac_async_write(&DAC_0, 0, &dc_out, 1);
// 	dac_sync_write(&DAC_0, 0, &dc_out, 1);
		
		dc_out ++;
// 	
// 
// 		dac_async_enable_channel(&DAC_0, 0);
// 		dac_async_register_callback(&DAC_0, DAC_ASYNC_CONVERSION_DONE_CB, tx_cb_DAC_0);
// 		dac_async_write(&DAC_0, 0, example_DAC_0, 10);


	
	if (prescaler){
		prescaler --;
	}
	else{
		prescaler = PRESCALER_VALUE;
		if (timeout_counter){
			timeout_counter --;
		}
	
		if (session_data.simulation_mode){		
			pulse_counter += 1;
			TR_counter += 1;
		
			if (pulse_counter >= session_data.pulse_length){ // slice acquisition starts
				pulse_counter = 0;
				if (session_data.current_slice < session_data.no_of_slices){
					session_data.current_slice += 1;
										
					uint16_t divider = session_data.trig_on_volume;
					if (divider == 0) {
						divider = 1;
					}
					if ((session_data.current_volume % divider) == 0){
						if ((session_data.trig_on_slice == 0) || (session_data.trig_on_slice == session_data.current_slice)){
							session_data.trigger = true;
							if (session_data.trigger_sound){
								//io_write_clear_ack(trig_rcvd,6);
								}
						}
					}
				}
			}
			if (TR_counter >= session_data.TR_time){ // new volume acquisition starts
				TR_counter = 0;
				pulse_counter = 0;
				session_data.current_volume += 1;
				session_data.current_slice = 0;
			}
		}
		//gpio_toggle_pin_level(T1);
	}
}

static void TIMER_task2_cb(const struct timer_task *const timer_task)
{
	if (adc_read){
		adc_read=false;
		//printf("ADC value: %d\r\n", adc_value);
		adc_async_start_conversion(&ADC_0);
	}
}

void TIMER_init(void)
{
	TIMER_0_task1.interval = 8; // 1.024 ms
	TIMER_0_task1.cb       = TIMER_task1_cb;
	TIMER_0_task1.mode     = TIMER_TASK_REPEAT;
	TIMER_0_task2.interval = 5000;
	TIMER_0_task2.cb       = TIMER_task2_cb;
	TIMER_0_task2.mode     = TIMER_TASK_REPEAT;

	timer_add_task(&TIMER_0, &TIMER_0_task1);
	timer_add_task(&TIMER_0, &TIMER_0_task2);
	timer_start(&TIMER_0);
}

int main(void)
{
	pb_received = false;
	uint16_t page_size;
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	ADC_init();
	adc_read=true;
	TIMER_init();
	uart_init();  // LCD communication
	
	page_size = flash_get_page_size(&FLASH_0);	
	printf("\r\nFLASH page size: %d\r\n", page_size);
	
	page_size=sizeof(session_data);
	printf("\r\nsession data size: %d\r\n", page_size);
	
	page_size=sizeof(session_data.sound_volume);
	printf("\r\nsound volume size: %d\r\n", page_size);
	
	page_size=sizeof(session_data.response_sound);
	printf("\r\nresponse sound size: %d\r\n", page_size);
	
	page_size=sizeof(session_data.current_form);
	printf("\r\ncurrent form size: %d\r\n", page_size);
	
			
	read_flash();
	
	session_data.trigger = false;
	session_data.session_running = false;
	session_data.current_form = DEFAULT_FORM;
	session_data.previous_form = DEFAULT_FORM;
	session_data.simulated_A = false;
	session_data.simulated_B = false;
	session_data.simulated_C = false;
	session_data.simulated_D = false;
	

	//hiddf_init();
	
	//printf("dac enable\r\n");
	//dac_sync_enable_channel(&DAC_0, 0);
	dac_async_enable_channel(&DAC_0, 0);
	
	printf("register ext irq sync trigger\r\n");
    ext_irq_register(I0, sync_trigger);
	
	printf("register ext irq button\r\n");
    ext_irq_register(PB2, button);
	
	printf("enable RX pwr\r\n");
	gpio_set_pin_level(RX_PWR, true);
	
	printf("reset LCD\r\n");
	gpio_set_pin_level(DISP_RESET, true);
	delay_ms(2000);
	printf("set ACK after display reset");
	ACK_received = true;

	while (1) {		
		
		if (session_data.session_running) {		
			
			if (session_data.previous_slice != session_data.current_slice){
				session_data.previous_slice = session_data.current_slice;				
				
				print_slices(CURRENT_SLICE_STR);
			}
			
			if (session_data.previous_volume != session_data.current_volume){
				session_data.previous_volume = session_data.current_volume;
				
				print_volumes(CURRENT_VOLUME_STR);			
			}
			
			if ((session_data.current_slice == session_data.no_of_slices) && (session_data.current_volume == session_data.no_of_volumes)) {
				session_data.session_running = false;
				delay_ms(1000);
				stop_session();
			}
		}
		
		else if (session_data.manual_trigger) {
			
			if (session_data.previous_slice != session_data.current_slice){
				session_data.previous_slice = session_data.current_slice;
				
				print_slices(MAN_TRIG_CURRENT_SLICE_STR);
			}
			
			if (session_data.previous_volume != session_data.current_volume){
				session_data.previous_volume = session_data.current_volume;
				
				print_volumes(MAN_TRIG_CURRENT_VOLUME_STR);

			}
			
			if ((session_data.current_slice == session_data.no_of_slices) && (session_data.current_volume == session_data.no_of_volumes)) {
				session_data.manual_trigger = false;
				delay_ms(2000);
				stop_man_trig();
			}
		}
		
		else if (session_data.simulation_mode) {
			
			if (session_data.previous_slice != session_data.current_slice){
				session_data.previous_slice = session_data.current_slice;
				print_slices(SIMULATION_CURRENT_SLICE_STR);

			}
			
			if (session_data.previous_volume != session_data.current_volume){
				session_data.previous_volume = session_data.current_volume;
				print_volumes(SIMULATION_CURRENT_VOLUME_STR);
			
			}			
	
			if ((session_data.current_slice == session_data.no_of_slices) && (session_data.current_volume == session_data.no_of_volumes)) {
				session_data.simulation_mode = false;
				delay_ms(2000);
				stop_simulation();
			}
		}
		
		if (pb_received){
			pb_received = false;
			if (session_data.session_running){
				printf("stop session by pushbutton\r\n");
				stop_session();
			}
			else{
				printf("start session by pushbutton\r\n");
				start_session();
			}
		}
				
		if (event_report.report_valid){			
			event_report.report_valid=false;
	
			switch (event_report.object_id) {
				uint8_t length = 0;
				case WINBUTTON:			
					
					printf("winbutton pressed, index: %u\r\n", event_report.object_index);
					
// 					if ((event_report.object_index < STOP_SIMULATION) && (event_report.object_index > MAN_TRIG_BACK)){ //avoid doubleclick with 'Both' action buttons
// 						if (event_report.value_lsb == 1){
// 							io_write_clear_ack(click,6);
// 						}
// 					}
// 					
// 					else {
// 						io_write_clear_ack(click,6);
// 					}
// 					delay_ms(click_delay);
					
					switch (event_report.object_index) {
						
						// **************** form0
						case START_SESSION:		
							
							start_session();
							
						break;
						
						case MENU:
							switch_to_form(MENU_FORM);
							printf("switching to form 7\r\n");
						
						break;
						
						
						// **************** form1
						case STOP_SESSION:
							stop_session();
							
						break;
						
						
						// **************** form2
						case MAN_TRIG_SEND_A:
							if (event_report.value_lsb == ON){
								session_data.simulated_A = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_A = false;
							}
							printf("simulated A\r\n");
						break;
						
						case MAN_TRIG_SEND_B:
							if (event_report.value_lsb == ON){
								session_data.simulated_B = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_B = false;
								
							}
							printf("simulated B\r\n");
						break;
						
						case MAN_TRIG_SEND_C:
							if (event_report.value_lsb == ON){
								session_data.simulated_C = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_C = false;
							
							}
							printf("simulated C\r\n");
						break;
						
						case MAN_TRIG_SEND_D:
							if (event_report.value_lsb == ON){
								session_data.simulated_D = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_D = false;
								
							}
							printf("simulated D\r\n");
						break;
						
						case MAN_TRIG_SEND_S:
							
							if ((event_report.value_lsb == ON) && (!session_data.simulation_mode) && (!session_data.session_running) && (session_data.manual_trigger)){
								printf("simulated S\r\n");
								delay_ms(10);
								session_data.current_slice += 1;
								if (session_data.current_slice > session_data.no_of_slices){
									session_data.current_volume += 1;
									session_data.current_slice = 1;
								}
								
								uint16_t divider = session_data.trig_on_volume;
								if (divider == 0) {
									divider = 1;
								}
								if ((session_data.current_volume % divider) == 0){
									if ((session_data.trig_on_slice == 0) || (session_data.trig_on_slice == session_data.current_slice)){
										session_data.trigger = true;
									}
								}
							}												
						
						break;
						
						case MAN_TRIG_BACK:
							stop_man_trig();						
						break;
						
						// ***********************   form3
						case SIMULATION_SEND_A:
							if (event_report.value_lsb == ON){
								session_data.simulated_A = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_A = false;
							}
							printf("simulated A\r\n");
						break;
						
						case SIMULATION_SEND_B:
							if (event_report.value_lsb == ON){
								session_data.simulated_B = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_B = false;
							}
							printf("simulated B\r\n");
						break;
						
						case SIMULATION_SEND_C:
							if (event_report.value_lsb == ON){
								session_data.simulated_C = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_C = false;
							}
							printf("simulated C\r\n");
						break;
						
						case SIMULATION_SEND_D:
							if (event_report.value_lsb == ON){
								session_data.simulated_D = true;
								delay_ms(10);
							}
							else{
								session_data.simulated_D = false;
							}
							printf("simulated D\r\n");
						break;
						
						case STOP_SIMULATION:
							stop_simulation();												
						break;
						
						// **************** form4
						case SET_SLICESNO_BTN:
							session_temp.parameter = SET_SLICESNO_BTN;
							switch_to_form(KEYBOARD_FORM);
							kb_value = session_temp.no_of_slices;
							minvalue = 1;
							maxvalue = 999;

							io_write_clear_ack(set_no_of_slices_txt,6);							
							print_no(kb_value, 11);
							printf("set slices no, switch to form 6\r\n");
						break;
						
						case SET_VOLUMESNO_BTN:
							session_temp.parameter = SET_VOLUMESNO_BTN;
							switch_to_form(KEYBOARD_FORM);
							kb_value = session_temp.no_of_volumes;
							minvalue = 1;
							maxvalue = 9999;
	
							io_write_clear_ack(set_no_of_volumes_txt,6);							
							print_no(kb_value, 11);							
							printf("set volumes no, switch to form 6\r\n");
						break;
						
						case FORM4_MORE:
							switch_to_form(SETTINGS_2_FORM);
							printf("form4 more, switch to form 5\r\n");
						break;
						
						case FORM4_ACCEPT:
							switch_to_form(MENU_FORM);
							session_data.no_of_slices = session_temp.no_of_slices;
							session_data.no_of_volumes = session_temp.no_of_volumes;
							session_data.trig_on_slice = session_temp.trig_on_slice;
							session_data.trig_on_volume = session_temp.trig_on_volume;
							session_data.pulse_length = session_temp.pulse_length;
							session_data.TR_time = session_temp.TR_time;
							printf("form4 accept, switch to form 7\r\n");
							
							write_flash();
							printf("FLASH written\r\n");
						break;
						
						case FORM4_CANCEL:
							switch_to_form(MENU_FORM);
							printf("form4 cancel, switch to form 7\r\n");
						break;
						
						
						// **************** form5
						case SLICE_TRIGGERNO_BTN:
							session_temp.parameter = SLICE_TRIGGERNO_BTN;
							switch_to_form(KEYBOARD_FORM);
 							kb_value = session_temp.trig_on_slice;
							minvalue = 0;
							maxvalue = 999;
							
							io_write_clear_ack(set_trigg_slice_txt,6);							
							print_no(kb_value, 11);							
							printf("set slice trigg no, switch to form 6\r\n");
						break;
						
						case VOLUME_TRIGGERNO_BTN:
							session_temp.parameter = VOLUME_TRIGGERNO_BTN;
							switch_to_form(KEYBOARD_FORM);
							kb_value = session_temp.trig_on_volume;
							minvalue = 0;
							maxvalue = 9999;
		
							io_write_clear_ack(set_trigg_volume_txt,6);							
							print_no(kb_value, 11);							
							printf("set volume trigg no, switch to form 6\r\n");
						break;
						
						case PULSE_LENGTH_BTN:
							session_temp.parameter = PULSE_LENGTH_BTN;
							switch_to_form(KEYBOARD_FORM);
							kb_value = session_temp.pulse_length;
							minvalue = 10;
							maxvalue = 999;
	
							io_write_clear_ack(set_pulse_length_txt,6);							
							print_no(kb_value, 11);							
							printf("set pulse length, switch to form 6\r\n");
						break;
						
						case TR_TIME_BTN:
							session_temp.parameter = TR_TIME_BTN;
							switch_to_form(KEYBOARD_FORM);
							kb_value = session_temp.TR_time;
							uint32_t minvalue_long = session_data.pulse_length * session_data.no_of_slices;
							if (minvalue_long > 9999){   // hibaellen�rz�s!!!!!!!!!!!!
								minvalue = 9999;
							}
							else{
								minvalue = minvalue_long;
							}
							maxvalue = 9999;
	
							io_write_clear_ack(set_tr_time_txt,6);							
							print_no(kb_value, 11);							
							printf("set TR time, switchto form 6\r\n");
						break;
						
						case FORM5_MORE:
							switch_to_form(SETTINGS_3_FORM);
							printf("form8 more, switch to form 8\r\n");
						break;
						
						case FORM5_ACCEPT:
							switch_to_form(MENU_FORM);
							session_data.no_of_slices = session_temp.no_of_slices;
							session_data.no_of_volumes = session_temp.no_of_volumes;
							session_data.trig_on_slice = session_temp.trig_on_slice;
							session_data.trig_on_volume = session_temp.trig_on_volume;
							session_data.pulse_length = session_temp.pulse_length;
							session_data.TR_time = session_temp.TR_time;
							printf("form5 accept, switch to form 7\r\n");
							
							write_flash();
							printf("FLASH written\r\n");
						break;
						
						case FORM5_CANCEL:
							switch_to_form(MENU_FORM);
							printf("form5 cancel, switch to form 7\r\n");
						break;
						
						// **************** form7
						case SETTINGS:
							session_temp.no_of_slices = session_data.no_of_slices;
							session_temp.no_of_volumes = session_data.no_of_volumes;
							session_temp.trig_on_slice = session_data.trig_on_slice;
							session_temp.trig_on_volume = session_data.trig_on_volume;
							session_temp.pulse_length = session_data.pulse_length;
							session_temp.TR_time = session_data.TR_time;
							
							switch_to_form(SETTINGS_1_FORM);							
							printf("settings, switch to form 4\r\n");
						break;
						
						case SIMULATION:
							start_simulation();
						break;
						
						case MANUAL_TRIGGER:
							start_man_trig();
						break;
						
						case MENU_BACK:
							switch_to_form(DEFAULT_FORM);
							printf("menu back, switch to form 0\r\n");
						break;
						
						case ABOUT:
							switch_to_form(ABOUT_FORM);
							printf("about, switch to form 0\r\n");
						break;


						// **************** form8
						case FORM8_MORE:
							switch_to_form(SETTINGS_1_FORM);
							printf("form4 more, switch to form 4  \r\n");
						break;
						
						case FORM8_ACCEPT:
							switch_to_form(MENU_FORM);
							session_data.no_of_slices = session_temp.no_of_slices;
							session_data.no_of_volumes = session_temp.no_of_volumes;
							session_data.trig_on_slice = session_temp.trig_on_slice;
							session_data.trig_on_volume = session_temp.trig_on_volume;
							session_data.pulse_length = session_temp.pulse_length;
							session_data.TR_time = session_temp.TR_time;
							printf("form4 accept, switch to form 7\r\n");
							
							write_flash();
							printf("FLASH written\r\n");
							
						break;
						
						
						// **************** form10
						case FORM10_BACK:
							switch_to_form(MENU_FORM);
							printf("form10 back, switch to menu form  \r\n");
						break;
												
						break;
						default:
						;
					}
				break;
				
				case FOURDBUTTON:
				
					printf("4dbutton pressed, index: %u, value: %u\r\n", event_report.object_index, event_report.value_lsb);
// 					io_write_clear_ack(click,6);					
// 					delay_ms(50);
					
					switch (event_report.object_index) {
						
						// **************** form0
						case TRIGGER_SOUND_SW:
							switch (event_report.value_lsb){
								case ON:
									io_write_clear_ack(set_trigger_sound_on,6);
									session_data.trigger_sound = true;
									printf("trigger snd switch is on\r\n");								
								break;
								
								case OFF:
									io_write_clear_ack(set_trigger_sound_off,6);
									session_data.trigger_sound = false;
									printf("trigger snd switch is off\r\n");	
								break;
									
								}
							break;
												
						case RESPONSE_SOUND_SW:
							switch (event_report.value_lsb){
								case ON:
									io_write_clear_ack(set_response_sound_on,6);
									session_data.response_sound = true;
									printf("response snd switch is on\r\n");	
								break;
								
								case OFF:
									io_write_clear_ack(set_response_sound_off,6);
									session_data.response_sound = false;
									printf("response snd switch is off\r\n");	
								break;
								
							}
						break;
												
						break;
						default:
						;
					}
					
				break;
						
				case KEYBOARD:
				
					printf("4dbutton pressed, index: %u, value: %u\r\n", event_report.object_index, event_report.value_lsb);
					
// 					io_write_clear_ack(click,6);					
// 					delay_ms(50);

					uint32_t prev_kb_value = kb_value;

					switch (event_report.value_lsb){
						case KEYBOARD_BACK:
							if (kb_value != 0){
								kb_value = kb_value / 10;
							}
							printf("back\r\n");
							
						break;
						
						case KEYBOARD_OK:
							printf("ok\r\n");
							
							if (kb_value < minvalue){
								kb_value = minvalue;
								print_no(kb_value, 11);
								delay_ms(500);
							}
							switch_to_form(session_data.previous_form);							
						
							switch (session_temp.parameter){
								case SET_SLICESNO_BTN:
									session_temp.no_of_slices = kb_value;																	
								break;
													
								case SET_VOLUMESNO_BTN:
									session_temp.no_of_volumes = kb_value;									
								break;
																					
								case SLICE_TRIGGERNO_BTN:
									session_temp.trig_on_slice = kb_value;									
								break;
													
								case VOLUME_TRIGGERNO_BTN:
									session_temp.trig_on_volume = kb_value;
								break;
													
								case PULSE_LENGTH_BTN:
									session_temp.pulse_length = kb_value;
								break;
													
								case TR_TIME_BTN:
									session_temp.TR_time = kb_value;
								break;
													
								default:
								break;
							}
							print_no(session_temp.no_of_slices, SET_SLICES_STR);
							print_no(session_temp.no_of_volumes, SET_VOLUMES_STR);
							print_no(session_temp.trig_on_slice, SLICE_TRIGGERNO_STR);
							print_no(session_temp.trig_on_volume, VOLUME_TRIGGERNO_STR);
							print_no(session_temp.pulse_length, PULSE_LENGTH_STR);
							print_no(session_temp.TR_time, TR_TIME_STR);
														
							printf("keyboard ok, switch back to form %u\r\n", session_data.previous_form);
							
						break;
						
						case KEYBOARD_CANCEL:
							printf("cancel\r\n");
							switch_to_form(session_data.previous_form);
							printf("keyboard cancel, switch back to form %u\r\n", session_data.previous_form);
							
						break;
						
						default:
						if ((event_report.value_lsb>0x29) && (event_report.value_lsb<0x3a)){
							unsigned char digit=event_report.value_lsb-0x30;
													
							kb_value = kb_value * 10 + digit;
							if (kb_value > maxvalue){
								kb_value = prev_kb_value;
							}
							
							printf("%i\r\n", digit);							
						}
						break;
					}
					printf("kb value: %lu, prev kb value: %lu\r\n", kb_value, prev_kb_value);
					print_no(kb_value, 11);
					
				break;
				default:
				;					
			}
			
			printf("Event received from %u, index: %u\r\n", event_report.object_id, event_report.object_index);
			
			//snprintf(buffer, 64, "%i\r\n", digit);
			//cdcdf_acm_write((uint8_t *) buffer, strnlen(buffer, 64));
		}
		
	}

}