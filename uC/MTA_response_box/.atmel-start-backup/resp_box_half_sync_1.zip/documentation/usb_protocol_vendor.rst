===================
USB Vendor Protocol
===================

USB Vendor Protocol is a part of the USB Device Stack library. It provides basic
macro definitions which are compliant with Universal Serial Bus Specification
Revision 2.0.


Applications
------------

N/A

Dependencies
------------

N/A


Limitations
-----------

N/A
